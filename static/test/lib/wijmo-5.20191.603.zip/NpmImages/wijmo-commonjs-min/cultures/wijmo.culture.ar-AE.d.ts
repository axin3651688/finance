declare module wijmo {
}
